import React from 'react';
import logo from './logo.svg';
import './App.css';
import Bar from './components/BarChart'
import "bootstrap/dist/css/bootstrap.min.css";
import Pie from "./components/SimplePieChart";

function App() {
  return (
    <div className="App"> 
      <Bar/>
      <Pie/>
    </div>
  );
}

export default App;
