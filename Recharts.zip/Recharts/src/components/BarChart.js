import React,{Component} from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend
  } from "recharts";

  const TABLE_LIST = [
    { name: "English", pv: 70, amt: 70 },
    { name: "Chemistry", pv: 60, amt: 60 },
    { name: "Physics", pv: 75, amt: 75 },
    { name: "Biology", pv: 50, amt: 50 },
    { name: "Maths", pv: 85, amt: 85 },
    { name: "Computer", pv: 100, amt: 100 },
    { name: "History", pv: 40, amt: 40 }
  ];

  export default class Chart extends Component {
    state = {
      list: [...TABLE_LIST]
    };

    render() {
        const { list } = this.state;
        return (
         
          <BarChart
            width={600}
            height={300}
            data={list}
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="pv" fill="#8884d8" />
          </BarChart>
        );
      }
    }
    